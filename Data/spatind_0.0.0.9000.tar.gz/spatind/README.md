# spatind

`spatind` is an R package for calculating spatial indicators used to describe population distribution, aggregation, occupancy, and range.

It includes both **spatially implicit** indicators based on catches or densities across samples, and **spatially explicit** indicators based on coordinates or gridded data.

---

## Installation

Install the development version from GitHub:

```r
remotes::install_github("peterjosephkidd/spatind")
```

Then load the package:

```r
library(spatind)
```

---

## Overview

The package includes functions for:

### Aggregation and occupancy indicators

- `spreadingarea()` — Spreading Area (SA)  
- `gini()` — Gini Index (G)  
- `positivearea()` — Positive Area (PA)  
- `proppres()` — Proportion of Presence (POP)  
- `equivalentarea()` — Equivalent Area (EA)  
- `densitylevel()` — Density Level (e.g. D95)  
- `spi()` — Spread of Participation Index (SPI)  

### Spatially explicit indicators

- `cog()` — Centre of Gravity (CoG)  
- `inertia()` — Spatial dispersion around CoG  
- `extentofoccurrence()` — Extent of Occurrence (EOO)  

---

## Examples

### Aggregation from sample densities

```r
library(spatind)

z <- c(3, 2, 8, 1)

spreadingarea(z)
gini(z)
positivearea(z)
proppres(z)
equivalentarea(z)
densitylevel(z)
```

---

### Weighted calculations

```r
z <- c(3, 2, 8, 1)
w <- c(2, 3, 1, 3)

spreadingarea(z, w)
gini(z, w)
positivearea(z, w)
proppres(z, w)
equivalentarea(z, w)
densitylevel(z, w)
```

---

### Centre of gravity (point data)

```r
x <- c(1, 2, 3)
y <- c(2, 4, 6)
z <- c(1, 5, 2)

cog(x, y, z)
```

---

### Inertia (gridded data)

```r
set.seed(1)
zmat <- matrix(sample(c(0, 1, 2), 100, replace = TRUE), nrow = 10)

inertia(z = zmat)
```

---

### Extent of occurrence

#### Point mode

```r
x <- c(1, 3, 4, 2.5, 5.5, -2.2, 2)
y <- c(55.5, 57, 54, 56.5, 58.5, 56, 52)

extentofoccurrence(x, y)
```

#### Matrix mode

```r
set.seed(1)
z <- matrix(sample(c(0, 0, 1), 100, replace = TRUE), nrow = 10)

extentofoccurrence(z = z, mode = "area")
extentofoccurrence(z = z, mode = "cells")
```

---

## Notes

- Functions support both **uniform weights** (`w = 1`) and **irregular sampling areas**.
- Missing values can be handled using `na.rm = TRUE`.
- Some plotting functionality requires additional packages (e.g. `ggplot2`, `paletteer`).
- Spatial functions may require additional dependencies (`sf`, etc.).

---

## Development status

This package is currently under development. Function interfaces and outputs may evolve.

---

## License

MIT License © Peter Joseph Kidd
