#' Cumulative Density Curve
#' @description Plot the cumulative density curve used for visualising the Gini Index (G) with Dx and the Spreading Area (SA).
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param curve Set to "SA" or "G" to specify whether to plot the curve representing the Spreading Area or the Gini Index, respectively.
#' @param dlevel Visualise Dx. An optional argument to plot the vertical line that intersects the Gini curve, e.g. set to 0.95 to represent the D95 indicator. Ranges from 0 to 1.
#' @param revdlvl Reverses the meaning of dlevel. If reverse = FALSE, Dx will be the proportion of density in x% of samples. If reverse = TRUE, Dx will be the area occupied by x% of the density.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A plot.
#' @export
#'
#' @importFrom graphics abline
#' @importFrom graphics mtext
#' @importFrom graphics text
#' @importFrom stats approxfun
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: Curve for Spreading Area
#' z <- c(0,0,4,2,8,5,3)
#' w <- c(1,1,3,2,5,7,2)
#' cumdenscurve(z, w, curve = "SA")
#'
#' # Example 2: curve for Gini Index with D95
#' cumdenscurve(z, w, curve = "G", dlevel = 0.95)

cumdenscurve <- function(z, w = 1, curve, dlevel = 0.95, revdlvl = FALSE, verbose = FALSE){
  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  if(curve != "G" && curve != "SA"){
    stop("Curve must be set to 'G' or 'SA'")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  zi <- z[order(z)]
  wi <- w[order(z)]
  n    <- length(z)          # number of samples
  T_   <- c(0,cumsum(wi))    # cumulative number of samples
  T_N  <- T_/sum(wi)         # cumulative proportion of samples
  qi   <- zi*wi              # total catches in each sample
  Q    <- sum(qi)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  QT   <- c(0,cumsum(qi))    # cumulative number of catches
  QT_Q <- QT/Q               # cumulative proportion of catch
  SA   <- sum((QT[1:n]+QT[2:(n+1)])*wi)/Q
  G    <- SA/sum(wi)


  if (curve == "SA"){
    mysub <- "Spreading Area (SA) = 2 x the area below the curve"
    plot(T_, QT_Q, main="SA Curve (Q(T))/Q", type="o", pch="+",
         xlab = "T",
         ylab = "Q(T)/Q")
    graphics::mtext(side = 3, line = 0, at = -0.05, adj = 0, cex = 0.7, mysub)
    graphics::text(max(T_)*0.05, 1, labels = paste0("SA = ", round(SA,2)))
  }

  if (curve == "G"){
    mysub <- paste0("Gini Index (G) = 2 x the area below the curve \n")
    plot(T_N, QT_Q, main="G Curve (Q(T/N))/Q", type="o", pch="+",
         xlab = "T/N",
         ylab = "Q(T)/Q")
    graphics::text(0.1, 1, labels = paste0("G = ", round(G,2)))

    if (!is.na(dlevel)) {

      if (dlevel < 0 | dlevel > 1) {
        warning("dlevel is set outside of 0 to 1. Result will not be meaningful.")
      }

      if (!revdlvl) {
      intrsct <- stats::approxfun(T_N, QT_Q)
      D <- intrsct(dlevel)       # Dx value
      graphics::abline(v = dlevel, col = "blue", lty = 2)
      mysub <- paste0(mysub, "D", dlevel*100, " is the proportion of density that occur in ", dlevel*100, "% of the samples/areas")
      } else if (revdlvl) {
        #intrsct <- stats::approxfun(QT_Q, T_N)
        #D <- intrsct(dlevel)       # Dx value

        graphics::abline(h = dlevel, col = "blue", lty = 2)
        mysub <- paste0(mysub, "D", dlevel*100, " is the proportion of samples/areas occupied by ", dlevel*100, "% of the density")
      }

      graphics::text(0.1, 0.9, labels = paste0("D", dlevel*100, " = ", round(D,2)))
    }

    graphics::mtext(side = 3, line = 0, at = -0.05, adj = 0, cex = 0.7, mysub)
  }
}

#' Cumulative Density Data
#' @description Produce a dataframe for plotting cumulative density curves.
#' * n:    number of samples
#' * q:    cathes in each area (z x w)
#' * Q:    total abundance (sum(q))
#' * QT:   cumulative catches across samples
#' * QT_Q: cumulative catches (QT) as a proportion of total abundance (Q). Used to plot both the curve representing the Spreading Area and Gini Index (y-axis).
#' * T:    cumulative areas/samples (used to plot Spreading Area on x-axis)
#' * T_N:  cumulative areas/samples as a proportion of the total area/number of samples (used to plot Gini curve on x-axis)
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A dataframe.
#' @export
#'
#' @importFrom stats approxfun
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: Curve for Spreading Area
#' z <- c(0,0,4,2,8,5,3)
#' w <- c(1,1,3,2,5,7,2)
#' cumdensdata(z, w)
#'
#' # Example 2: curve for Gini Index with D95
#' cumdensdata(z, w)

cumdensdata <- function(z, w = 1, verbose = FALSE){
  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  zi <- z[order(z)]
  wi <- w[order(z)]
  n    <- length(z)          # number of samples
  T_   <- c(0,cumsum(wi))    # cumulative number of samples
  T_N  <- T_/sum(wi)         # cumulative proportion of samples
  qi   <- zi*wi              # total catches in each sample
  Q    <- sum(qi)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  QT   <- c(0,cumsum(qi))    # cumulative number of catches
  QT_Q <- QT/Q               # cumulative proportion of catch

  df <- data.frame(
    n    = rep(n,n+1),
    q    = c(0,zi*wi),
    Q    = rep(Q,n+1),
    QT   = QT,
    QT_Q = QT_Q,
    "T"  = T_,
    T_N  = T_N
  )
  return(df)
}
