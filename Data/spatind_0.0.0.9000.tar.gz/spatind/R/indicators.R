#' Spreading Area (SA)
#' @description The Spreading Area (SA) is a spatially implicit indicator that measures how aggregated individuals are across a sampled region. The SA is the area under the curve of cumulative density against the number of samples. Lower values of SA indicate higher aggregation. A uniformly spread population will have a high value of SA. The SA is not sensitive to zero density samples (unlike the Gini Index). The SA is equal to the Gini Index multiplied by the number of density samples in `z` (SA = G*n). The SA will equal the Positive Area (PA) if density values are equally distributed across samples (e.g. `z <- c(2,2,2,2)`).
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' spreadingarea(z)
#'
#' # Example 2: Uniform weights
#' spreadingarea(z, w = 1)
#' spreadingarea(z, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' spreadingarea(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(spreadingarea(z, w = c(1,2))) # gives error
#' spreadingarea(z, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Relationship with Gini Index (G)
#' spreadingarea(z) == gini(z)*length(z)
#'
#' # Example 6: Relationship with Positive Area (PA)
#' z <- c(2,2,2,2) # uniform density distribution
#' spreadingarea(z) == positivearea(z) # TRUE
#'
#' w <- c(1,2,3,4)
#' spreadingarea(z, w) == positivearea(z, w) # FALSE
spreadingarea <- function(z, w = 1, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
      if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
      w <- rep(1, length(z))
    } else if(length(w) == 1) {
      if (verbose) message("Weights (w) equal for all samples.")
      w <- rep(w, length(z))
    }

  zi <- z[order(z)]
  wi <- w[order(z)]
  n  <- length(z)          # number of samples
  qi <- zi*wi              # total catches in each sample
  Q  <- sum(qi)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  QT <- c(0,cumsum(qi))    # cumulative frequency of catches
  SA <- sum((QT[1:n]+QT[2:(n+1)])*wi)/Q

  return(SA)
}

#' Gini Index (G)
#' @description The Gini Index (G) is a spatially implicit indicator that measures how aggregated individuals are across a sampled region. The G is the area under the curve of cumulative density against the number of samples. Lower values of G indicate higher aggregation. A uniformly spread population will have a high value of G. The G ranges from 0 to 1. The G is sensitive to zero density samples (unlike the Spreading Area). The G is equal to the Spreading Area divived by the number of density samples in `z`(G = SA/n). The G will equal the Proportion of Presence (POP) if density values are equally distributed across samples (e.g. `z <- c(2,2,2,2)`).
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' gini(z)
#'
#' # Example 2: Uniform weights
#' gini(z, w = 1)
#' gini(z, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' gini(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(gini(z, w = c(1,2))) # gives error
#' gini(z, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Relationship with Spreading Area (SA)
#' gini(z) == spreadingarea(z)/length(z)
#'
#' # Example 6: Relationship with Proportion of Presence (POP)
#' z <- c(2,2,2,2) # uniform density distribution
#' gini(z) == proppres(z) # TRUE
#'
#' w <- c(1,2,3,4)
#' gini(z, w) == proppres(z, w) # FALSE
#'
gini <- function(z, w = 1, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  zi <- z[order(z)]
  wi <- w[order(z)]
  n  <- length(z)          # number of samples
  qi <- zi*wi              # total catches in each sample
  Q  <- sum(qi)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  QT <- c(0,cumsum(qi))    # cumulative frequency of catches...
  QT_Q <- QT/Q             # ... relative to total abundance
  G <- sum((QT_Q[1:n]+QT_Q[2:(n+1)])*wi)/sum(wi) # Gini calculation

  return(G)
}

#' Positive Area (PA)
#' @description The Positive Area (PA) is the area/number of samples with density values greater than 0 (i.e. z > 0).
#'
#' @param z Catches per unit area or binary-presence absence data.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 equates to counting the number of densities in `z` that are greater than 0.
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' positivearea(z)
#'
#' # Example 2: Uniform weights
#' positivearea(z, w = 1)
#' positivearea(z, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' positivearea(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(positivearea(z, w = c(1,2))) # gives error
#' positivearea(z, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Relationship with Proportion of Presence (POP)
#' positivearea(z) == proppres(z)*length(z)
#'
#' # Example 6: Relationship with Spreading Area (SA)
#' z <- c(2,2,2,2) # uniform density distribution
#' positivearea(z) == spreadingarea(z) # TRUE
#'
#' w <- c(1,2,3,4)
#' positivearea(z, w) == spreadingarea(z, w) # FALSE
positivearea <- function(z, w = 1, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  PA <- sum(w[z>0])

  return(PA)
}

#' The Proportion of Presence (POP)
#' @description The Proportion of Presence (POP) is the proportion of area/samples with density values greater than 0 (i.e. z > 0).
#'
#' @param z Catches per unit area or binary presence-absence data.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 equates to counting the number of densities in `z` that are greater than 0.
#' @param threshold Numeric between 0 and 1 defining the density threshold for presence. If `threshold = 0`, presence is defined as `z > 0`. If `threshold > 0`, presence is defined as values of `z` greater than the corresponding quantile of `z`.
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' proppres(z)
#'
#' # Example 2: Uniform weights
#' proppres(z, w = 1)
#' proppres(z, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' proppres(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(proppres(z, w = c(1,2))) # gives error
#' proppres(z, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Relationship with Proportion of Presence (POP)
#' # Only true when weights are uniform (e.g. w = 1)
#' proppres(z) == positivearea(z)/length(z)
#'
#' # Example 6: Relationship with Gini Index (SA)
#' z <- c(2,2,2,2) # uniform density distribution
#' proppres(z) == gini(z) # TRUE
#'
#' w <- c(1,2,3,4)
#' proppres(z, w) == gini(z, w) # FALSE
proppres <- function(z, w = 1, threshold = 0, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  stopifnot(is.finite(threshold), threshold >= 0, threshold <= 1)


  q <- if (threshold == 0) {
    0
  } else {
    quantile(z, probs = threshold, na.rm = TRUE, names = FALSE)
  }

  POP <- sum(w[z>q]) / sum(w)

  return(POP)
}

#' Equivalent Area (EA)
#' @description The Equivalent Area (EA) is a spatially implicit indicator that measures how aggregated individuals are across a sampled region. Lower values of EA indicate higher aggregation. A uniformly spread population will have a high value of EA. The EA is not sensitive to zero density samples.
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' equivalentarea(z)
#'
#' # Example 2: Uniform weights
#' equivalentarea(z, w = 1)
#' equivalentarea(z, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' equivalentarea(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(equivalentarea(z, w = c(1,2))) # gives error
#' equivalentarea(z, w = c(1,2,NA,5)) # defaults to w = 1
equivalentarea <- function(z, w = 1, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  } else{
    w <- w
  }
  zi <- z[order(z)]
  wi <- w[order(z)]
  EA <- sum(zi*wi,na.rm=T)^2 / sum(zi^2*wi,na.rm=T)
  return(EA)

}


#' Density Level (D95)
#' @description The Density Level (D) is a spatially implicit indicator that measures how aggregated individuals are across a sampled region. Lower values of D indicate higher aggregation. A uniformly spread population will have a high value of D. The D is sensitive to zero density samples. The value of D will equal the dlevel when densities are evenly distributed.
#'
#' @param z Catches per unit area.
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or a numerical value (e.g. `1.3`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param dlevel The proportion of catches in x% of the samples/sampled area, where x = dlevel x 100. The dlevel must be within 0 and 1. Defaults to 0.95.
#' @param reverse Reverses the meaning of dlevel. If reverse = FALSE, Dx will be the proportion of density in x% of samples. If reverse = TRUE, Dx will be the area occupied by x% of the density.
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` values if `w` is a vector). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#'
#' # Example 1: No weights provided
#' densitylevel(z)
#'
#' # Example 2: Uniform weights
#' densitylevel(z, w = 1)
#' densitylevel(z, w = 3.2, verbose = FALSE)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' densitylevel(z, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(densitylevel(z, w = c(1,2))) # gives error
#' densitylevel(z, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Uniform distribution
#' z <- c(5,5,5,5)
#' densitylevel(z, dlevel = 0.95)
#' densitylevel(z, dlevel = 0.75)
#' densitylevel(z, dlevel = 0.5)
#'
#' # Example 6: Reverse mode - proportion of area needed to contain 95% of the density
#'z <- c(0, 0, 1, 5, 10)
#'w <- c(1, 1, 1, 1, 1)
#'densitylevel(z, w, dlevel = 0.95, reverse = TRUE)
densitylevel <- function(z, w = 1, dlevel = 0.95, reverse = FALSE, na.rm = FALSE, verbose = FALSE){

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  if (dlevel < 0 | dlevel > 1) {
    warning("The dlevel is set outside of 0 to 1. Result will not be meaningful.")
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  }

  zi <- z[order(z)]
  wi <- w[order(z)]
  n    <- length(z)          # number of samples
  T_   <- c(0,cumsum(wi))    # cumulative number of samples
  T_N  <- T_/sum(wi)         # cumulative proportion of samples
  qi   <- zi*wi              # total catches in each sample
  Q    <- sum(qi)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  QT   <- c(0,cumsum(qi))    # cumulative number of catches
  QT_Q <- QT/Q               # cumulative proportion of catch

  if (!reverse) {
    intrsct <- stats::approxfun(T_N, QT_Q)
    D <- intrsct(dlevel)
  } else if (reverse) {
    intrsct <- stats::approxfun(QT_Q, T_N)
    D <- intrsct(dlevel)
  }

  return(D)
}

#' Spread of Participation Index (SPI)
#' @description The SPI is a spatially implicit indicator that measures how aggregated individuals are across a sampled region. Lower values of SPI indicate higher aggregation. A uniformly spread population will have a high value of D. The D is sensitive to zero density samples. The value of D will equal the dlevel when densities are evenly distributed.
#'
#' @param z Catches per unit area.
#' @param r Regions associated with each catch (e.g. individual rectangles from a grid or areas defined by habitat type).
#' @param w Weights for each area. Can be a vector (e.g. `c(1,2,3)`) or an integer (e.g. `1`), depending on whether areas are irregular or uniform. Defaults to 1 if no weights are provided or if there are missing weights. A value of 1 means that densities (zi) equals catches (qi).
#' @param na.rm Logical. If TRUE, remove `NA` values in `z` (and corresponding `w` and `r` values). If FALSE and any `NA` values exist in `z`, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @examples
#' z <- c(3,2,8,1)
#' r <- c(1,2,3,4)
#'
#' # Example 1: No weights provided
#' spi(z, r)
#'
#' # Example 2: Uniform weights
#' spi(z, r, w = 1)
#' spi(z, r, w = 3.2)
#'
#' # Example 3: Irregular weights
#' w <- c(2,3,1,3)
#' spi(z, r, w)
#'
#' # Example 4: Miss-specifying `w`
#' try(spi(z, r, w = c(1,2))) # gives error
#' spi(z, r, w = c(1,2,NA,5)) # defaults to w = 1
#'
#' # Example 5: Multiple catches from within the same region
#' r <- c(3,1,2,1)
#' spi(z, r, w = 1)
#' spi(z, r, w)

spi <- function(z, r, w = 1, na.rm = FALSE, verbose = FALSE) {

  z <- as.vector(z)
  r <- as.vector(r)

  if(all(is.na(z))) {
    if (verbose) message("All z values are NA. Returning NA.")
    return(NA)
  }

  if(any(is.na(z))) {
    if(na.rm == FALSE) {
      if (verbose) message("Some z values are NA. Returning NA.")
      return(NA)
    } else if(na.rm == TRUE) {
      keep <- !is.na(z)
      z <- z[keep]
      if (length(w) > 1) w <- w[keep]
      r <- r[keep]
    }
  }

  if(length(w) != length(z) && length(w) != 1) {
    stop("Length of area weights (w) must either be of length 1 or match the length of densities (z).")
  }

  # Weights for areas/samples
  if(any(is.na(w))) {
    if (verbose) message("No or missing weights (w) provided. Defaulting to 1.")
    w <- rep(1, length(z))
  } else if(length(w) == 1) {
    if (verbose) message("Weights (w) equal for all samples.")
    w <- rep(w, length(z))
  } else{
    w <- w
  }

  if(any(is.na(r))){
    r <- seq(1, length(z))
  }

  qi <- z*w               # observed catches

  if (length(qi) != length(r)) {
    stop(sprintf("spi(): length mismatch at tapply: length(z)=%d length(w)=%d length(qi)=%d length(r)=%d | class(r)=%s",
                 length(z), length(w), length(qi), length(r), paste(class(r), collapse=",")),
         call. = FALSE)
  }

  fo <- tapply(qi,r,sum)   # sum of catches in each region
  Q  <- sum(fo)            # total abundance

  if (Q == 0) {
    if (verbose) message("Total abundance is zero. Returning 0.")
    return(0)
  }

  nr <- length(unique(r))  # number of regions
  t  <- tapply(w, r, unique)

  checks <- c()

  for (i in 1:nr) {
    if (length(t[[i]]) > 1) {
      checks <- c(checks, i)
    }
  }

  if (!is.null(checks)) {
    stop(paste0("Area weights (w) for densities (z) in the same region (r) must be identical. Different area weights have been set for region(s) ", paste0(checks, collapse = ", ")))
  }

  proparea <- t/nr         # proportion of total area that each region constitutes
  fe <- Q*proparea         # expected densities from a uniformly distributed population
  fo_fe <- sum(abs(fo-fe)) # sum of the absolute differences between observed and expected frequencies
  femin <- proparea[proparea==min(proparea)][1]*Q # expected density in the smallest region
  out <- 1-((fo_fe)/(2*(Q-femin))[[1]])

  return(out)
}

#' Extent of Occurrence (EOO) old
#' @description The Extent of Occurrence (EOO) is a spatially explicit indicator that measures the range of a population. It is the area (km2) of the convex hull polygon drawn around sample sites with species presence. This indicator requires the longitude and latitude coordinates of presence data.
#'
#' @param x Vector of x coordinates representing the geographical location of occurence points.
#' @param y Vector of y coordinates representing the geographical location of occurence points.
#' @param p Produce a map of the extent of occurrence. Default = F.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#'
#' @return A numerical value.
#' @export
#'
#' @import ggplot2
#' @importFrom grDevices chull
#' @importFrom sfheaders sf_polygon
#' @importFrom sf st_area
#' @importFrom sf st_transform
#' @importFrom sf st_centroid
#' @importFrom sf st_coordinates
#' @importFrom sf st_as_sf
#' @importFrom sf st_bbox
#' @importFrom stats na.omit
#' @importFrom maps map
#'
#' @examples
#' # Example 1
#' x <- c(1, 3, 4, 2.5, 5.5, -2.2, 2)
#' y <- c(55.5, 57, 54, 56.5, 58.5, 56, 52)
#'
#' extentofoccurrence(x, y, p =TRUE)

extentofoccurrence_old <- function(x, y, p = FALSE, verbose = FALSE) {

  if (length(x) != length(y)){
    stop("Length of x and y vectors must match.")
  }

  if (any(is.na(x)) | any(is.na(y))){
    if (verbose) message("Removing coordinates with NAs in x or y.")
  }

  xy <- na.omit(cbind(x, y))[,1:2]

  xy_chull <- grDevices::chull(xy)
  x_chull  <- xy[xy_chull,1]
  y_chull  <- xy[xy_chull,2]

  # Close the polygon
  x_chull  <- c(x_chull, x_chull[1])
  y_chull  <- c(y_chull, y_chull[1])


  # UTM transformation
  utm_latzones <- floor(((x_chull+180)/6)+1)

  # Get the mode
  u <- unique(utm_latzones)
  tab <- tabulate(match(utm_latzones, u))
  utm_long <- u[tab == max(tab)][1]

  if (all(y_chull >= 0)) {
    utm_lat <- 326
  } else if(all(y_chull <= 0)) {
    utm_lat <- 327
  } else{
    warning("Geographical cooridnates span over both northern and southern hemisphere. UTM transformation may not be appropriate.")
    nn <- length(y_chull >=0)
    ns <- length(x_chull <=0)

    if(nn > ns) {
      utm_lat <- 326 # more points in northern hemisphere
    } else if(nn < ns) {
        utm_lat <- 327 # more points in southern hemisphere
    } else {
        stop("Equal number of points in northern and southern hemisphere. UTM transformation is not appropriate.")
      }
  }

  utm_code <- paste0("EPSG:",utm_lat, utm_long)

  chull_points <- as.data.frame(xy[xy_chull, ])

  chull_poly <- sfheaders::sf_polygon(
    obj = chull_points
    , x = "x"
    , y = "y")

  chull_poly_plot <- sf::st_set_crs(chull_poly, 4326)
  chull_poly <- sf::st_transform(chull_poly_plot, utm_code)

  eoo <- as.double(paste0(sf::st_area(chull_poly)/1000000))

  if(p){
    world_map <- sf::st_as_sf(maps::map("world", fill = TRUE, plot = FALSE))
    world_map <- sf::st_transform(world_map, 4326)

    centroid <- sf::st_centroid(chull_poly_plot)
    centroid_coords <- sf::st_coordinates(centroid)

    ggplot2::ggplot() +
      ggplot2::geom_sf(data = world_map, fill = "lightgrey", color = "black") +
      ggplot2::geom_sf(data = chull_poly_plot, fill = "lightblue", color = "blue", alpha = 0.5) +
      ggplot2::geom_point(data = xy, aes(x=x, y=y), colour = "blue") +
      ggplot2::geom_text(aes(x = centroid_coords[1], y = centroid_coords[2], label = paste("EOO = ", round(eoo,2), "km2"))) +
      ggplot2::ggtitle("Extent of Occurrence Map") +
      ggplot2::theme_minimal() +
      ggplot2::coord_sf(xlim = sf::st_bbox(chull_poly_plot)[c("xmin", "xmax")],
               ylim = sf::st_bbox(chull_poly_plot)[c("ymin", "ymax")]) +
      ggplot2::xlab("Longitude") +
      ggplot2::ylab("Latitude")
  }

  return (eoo)

}

#' Centre of Gravity (CoG)
#'
#' @description
#' Computes the Centre of Gravity (CoG), defined as the density-weighted mean
#' location of a population. The function can be applied to either point data
#' (vectors of coordinates) or gridded data (matrices). Optional coordinate
#' transformations between longitude/latitude and kilometres are supported.
#'
#' @param x Numeric vector or matrix of x-coordinates. In matrix mode, `x` can
#'   either be a vector of length `ncol(z)` representing cell centres, or a matrix
#'   with the same dimensions as `z`.
#' @param y Numeric vector or matrix of y-coordinates. In matrix mode, `y` can
#'   either be a vector of length `nrow(z)` representing cell centres, or a matrix
#'   with the same dimensions as `z`.
#' @param z Density values used as weights. Can be a numeric vector (point data),
#'   a numeric matrix (gridded data), or a single numeric value (equal weighting).
#'   Defaults to 1 (unweighted mean location).
#' @param plot Logical. Should the data and Centre of Gravity be plotted?
#'   Defaults to FALSE.
#' @param lonlat2km Logical. Convert longitude/latitude coordinates to kilometres
#'   using \code{SpatialEpi::latlong2grid}? Defaults to FALSE.
#' @param km2lonlat Logical. Convert kilometre coordinates to longitude/latitude
#'   using \code{SpatialEpi::grid2latlong}? Defaults to FALSE.
#' @param na.rm Logical. Remove rows or cells with non-finite values before
#'   computing the CoG? Defaults to TRUE.
#' @param which Character string specifying which output to return. One of
#'   \code{"both"} (default), \code{"x"}, or \code{"y"}. If \code{"x"} or
#'   \code{"y"}, a single numeric value is returned.
#'
#' @return
#' If \code{which = "both"}, a data frame with columns \code{cog_x} and
#' \code{cog_y}. If \code{which = "x"} or \code{which = "y"}, a single numeric
#' value corresponding to the requested coordinate.
#'
#' @export
#'
#' @examples
#' # Example 1: Point data (unweighted)
#' x <- c(1, 2, 3)
#' y <- c(2, 4, 6)
#' cog(x, y)
#'
#' # Example 2: Point data with density weighting
#' z <- c(1, 5, 2)
#' cog(x, y, z)
#'
#' # Example 3: Only return x-coordinate
#' cog(x, y, z, which = "x")
#'
#' # Example 4: Gridded data (matrix mode)
#' x_centres <- seq(0.5, 4.5, by = 1)
#' y_centres <- seq(0.5, 2.5, by = 1)
#' zmat <- matrix(runif(15), nrow = 3, ncol = 5)
#' cog(x_centres, y_centres, zmat)
#'
#' # Example 5: Plot Centre of Gravity
#' cog(x_centres, y_centres, zmat, plot = TRUE)
cog <- function(x, y, z = 1,
                plot = FALSE,
                lonlat2km = FALSE,
                km2lonlat = FALSE,
                na.rm = TRUE,
                which = c("both", "x", "y")) {

  which <- match.arg(which)
  matrix_mode <- is.matrix(z)

  if (!matrix_mode) {

    if (length(z) == 1) z <- rep(z, length(x))
    if (length(x) != length(y) || length(x) != length(z)) {
      stop("In point mode, x, y, and z must have the same length (or z length 1).")
    }

    d <- data.frame(x = x, y = y, z = z)

  } else {

    nr <- nrow(z)
    nc <- ncol(z)

    if (is.vector(x) && length(x) == nc &&
        is.vector(y) && length(y) == nr) {

      xy <- expand.grid(x = x, y = y)
      d <- data.frame(
        x = xy$x,
        y = xy$y,
        z = as.vector(t(z))
      )

    } else if (is.matrix(x) && is.matrix(y) &&
               all(dim(x) == dim(z)) &&
               all(dim(y) == dim(z))) {

      d <- data.frame(
        x = as.vector(x),
        y = as.vector(y),
        z = as.vector(z)
      )

    } else {
      stop(
        "Matrix mode requires either:\n",
        "- x = length ncol(z) vector and y = length nrow(z) vector, or\n",
        "- x and y matrices with same dimensions as z."
      )
    }
  }

  if (na.rm) {
    d <- d[is.finite(d$x) & is.finite(d$y) & is.finite(d$z), , drop = FALSE]
  }

  if (lonlat2km) {
    d_km <- SpatialEpi::latlong2grid(as.matrix(d[, c("x", "y", "z")]))
    d$x <- d_km[, 1]
    d$y <- d_km[, 2]
  }

  if (km2lonlat) {
    d_ll <- SpatialEpi::grid2latlong(as.matrix(d[, c("x", "y", "z")]))
    d$x <- d_ll[, 1]
    d$y <- d_ll[, 2]
  }

  zsum <- sum(d$z)

  if (!is.finite(zsum) || zsum == 0) {
    cog_x <- NA_real_
    cog_y <- NA_real_
  } else {
    cog_x <- sum(d$x * d$z) / zsum
    cog_y <- sum(d$y * d$z) / zsum
  }

  if (plot) {

    if (!matrix_mode) {

      d$a <- if (length(unique(d$z)) == 1) NA_real_ else d$z

      p <- ggplot() +
        geom_point(data = d, aes(x, y, colour = .data$a),
                   size = pmax(1, d$z)) +
        geom_point(data = data.frame(cog_x = cog_x, cog_y = cog_y),
                   aes(cog_x, cog_y),
                   colour = "blue", shape = 15, size = 2) +
        geom_text(data = data.frame(cog_x = cog_x, cog_y = cog_y),
                  aes(cog_x, cog_y - (cog_y * 0.02), label = "CoG")) +
        labs(colour = "z")

      print(p)

    } else {

      p <- ggplot(d, aes(x, y, fill = z)) +
        geom_tile() +
        geom_point(data = data.frame(cog_x = cog_x, cog_y = cog_y),
                   aes(cog_x, cog_y),
                   inherit.aes = FALSE,
                   colour = "blue", shape = 15, size = 2) +
        geom_text(data = data.frame(cog_x = cog_x, cog_y = cog_y),
                  aes(cog_x, cog_y, label = "CoG"),
                  inherit.aes = FALSE,
                  vjust = 1.5) +
        labs(fill = "z")

      print(p)
    }
  }

  if (which == "x") return(cog_x)
  if (which == "y") return(cog_y)

  data.frame(cog_x = cog_x, cog_y = cog_y)
}

#' Extent of Occurrence (EOO)
#'
#' @description
#' The Extent of Occurrence (EOO) is a spatially explicit indicator of range. In
#' point mode, EOO is the area (km\eqn{^2}) of the convex hull around occurrence
#' points provided as longitude/latitude. In matrix mode, occurrence is inferred
#' from a regular grid (one matrix element equals one grid cell) and EOO can be
#' returned either as convex hull area in grid units (or km\eqn{^2} if cell size is
#' supplied) or as the number of grid cells contained within the convex hull.
#'
#' @details
#' Matrix mode assumes each element of `z` represents one grid cell in a regular
#' grid and cell coordinates are inferred from matrix indices (column = x, row = y).
#' Presence cells are defined by `z > presence`.
#'
#' @param x Vector of x coordinates (longitude) for occurrence points. Required in
#'   point mode (`z = NULL`). Ignored in matrix mode.
#' @param y Vector of y coordinates (latitude) for occurrence points. Required in
#'   point mode (`z = NULL`). Ignored in matrix mode.
#' @param z Optional matrix of density/presence values. If provided, the function
#'   operates in matrix mode.
#' @param p Logical. Produce a plot. Default = FALSE.
#' @param na.rm Logical. If TRUE, remove `NA` values in inputs before computation.
#'   If FALSE and any `NA` values exist in the required inputs, return `NA`.
#' @param verbose Toggle function messages. TRUE = on, FALSE = off.
#' @param cell_km Optional numeric vector of length 2 giving grid cell dimensions
#'   in kilometres: `c(dx, dy)`. Used only in matrix mode to convert grid units to
#'   km\eqn{^2}. Default = NULL (returns grid units or cell counts).
#' @param mode Character string specifying the matrix-mode output. `"area"` returns
#'   convex hull area (grid units or km\eqn{^2} if `cell_km` is provided). `"cells"`
#'   returns the number of grid cells whose centres fall inside or on the convex hull
#'   (or converts to km\eqn{^2} if `cell_km` is provided).
#' @param presence Numeric threshold defining presence in matrix mode. Cells with
#'   `z > presence` are considered present. Default = 0.
#'
#' @return A numeric value. In point mode, km\eqn{^2}. In matrix mode, either hull
#'   area (grid units or km\eqn{^2}) or number of cells (or km\eqn{^2} if converted),
#'   depending on `mode` and `cell_km`.
#'
#' @export
#'
#' @importFrom grDevices chull
#' @importFrom stats na.omit
#' @importFrom sf st_area st_transform st_centroid st_coordinates st_as_sf st_bbox st_set_crs st_intersects
#' @importFrom sfheaders sf_polygon
#' @importFrom maps map
#'
#' @examples
#' # Point mode
#' x <- c(1, 3, 4, 2.5, 5.5, -2.2, 2)
#' y <- c(55.5, 57, 54, 56.5, 58.5, 56, 52)
#' extentofoccurrence(x, y)
#'
#' # Matrix mode
#' set.seed(1)
#' z <- matrix(sample(c(0, 0, 1), 100, replace = TRUE), nrow = 10)
#' extentofoccurrence(z = z, mode = "area")
#' extentofoccurrence(z = z, mode = "cells")
#' extentofoccurrence(z = z, mode = "cells", cell_km = c(2, 2))
extentofoccurrence <- function(x = NULL, y = NULL, z = NULL,
                               p = FALSE, na.rm = TRUE, verbose = FALSE,
                               cell_km = NULL,
                               mode = c("area", "cells"),
                               presence = 0) {

  mode <- match.arg(mode)
  stopifnot(is.finite(presence))

  # ---- Point (lon/lat) mode
  if (is.null(z)) {

    if (is.null(x) || is.null(y)) {
      stop("In point mode (z is NULL), you must provide x and y vectors.")
    }
    if (length(x) != length(y)) {
      stop("Length of x and y vectors must match.")
    }

    if (anyNA(x) || anyNA(y)) {
      if (!na.rm) {
        if (verbose) message("Some x/y values are NA. Returning NA.")
        return(NA_real_)
      } else {
        if (verbose) message("Removing coordinates with NAs in x or y.")
      }
    }

    xy <- if (na.rm) {
      stats::na.omit(cbind(x, y))[, 1:2, drop = FALSE]
    } else {
      cbind(x, y)
    }
    colnames(xy) <- c("x", "y")

    if (nrow(xy) < 3) {
      if (verbose) message("Fewer than 3 occurrence points. Convex hull undefined. Returning 0.")
      return(0)
    }

    xy_chull <- grDevices::chull(xy)
    x_chull  <- xy[xy_chull, 1]
    y_chull  <- xy[xy_chull, 2]

    x_chull <- c(x_chull, x_chull[1])
    y_chull <- c(y_chull, y_chull[1])

    utm_latzones <- floor(((x_chull + 180) / 6) + 1)
    u <- unique(utm_latzones)
    tab <- tabulate(match(utm_latzones, u))
    utm_long <- u[tab == max(tab)][1]

    if (all(y_chull >= 0)) {
      utm_lat <- 326
    } else if (all(y_chull <= 0)) {
      utm_lat <- 327
    } else {
      warning("Geographical coordinates span both hemispheres. UTM transformation may not be appropriate.")
      nn <- sum(y_chull >= 0)
      ns <- sum(y_chull < 0)
      if (nn > ns) {
        utm_lat <- 326
      } else if (nn < ns) {
        utm_lat <- 327
      } else {
        stop("Equal number of points in northern and southern hemisphere. UTM transformation is not appropriate.")
      }
    }

    utm_code <- paste0("EPSG:", utm_lat, utm_long)

    chull_points <- data.frame(x = xy[xy_chull, 1], y = xy[xy_chull, 2])
    chull_poly <- sfheaders::sf_polygon(obj = chull_points, x = "x", y = "y")

    chull_poly_plot <- sf::st_set_crs(chull_poly, 4326)
    chull_poly_utm  <- sf::st_transform(chull_poly_plot, utm_code)

    eoo <- as.double(sf::st_area(chull_poly_utm) / 1e6)

    if (p) {
      world_map <- sf::st_as_sf(maps::map("world", fill = TRUE, plot = FALSE))
      world_map <- sf::st_transform(world_map, 4326)

      centroid <- sf::st_centroid(chull_poly_plot)
      centroid_coords <- sf::st_coordinates(centroid)

      plt <- ggplot2::ggplot() +
        ggplot2::geom_sf(data = world_map, fill = "lightgrey", color = "black") +
        ggplot2::geom_sf(data = chull_poly_plot, fill = "lightblue", color = "blue", alpha = 0.5) +
        ggplot2::geom_point(data = as.data.frame(xy), ggplot2::aes(x = x, y = y), colour = "blue") +
        ggplot2::geom_text(ggplot2::aes(x = centroid_coords[1], y = centroid_coords[2],
                                        label = paste("EOO = ", round(eoo, 2), "km2"))) +
        ggplot2::ggtitle("Extent of Occurrence Map") +
        ggplot2::theme_minimal() +
        ggplot2::coord_sf(
          xlim = sf::st_bbox(chull_poly_plot)[c("xmin", "xmax")],
          ylim = sf::st_bbox(chull_poly_plot)[c("ymin", "ymax")]
        ) +
        ggplot2::xlab("Longitude") +
        ggplot2::ylab("Latitude")

      print(plt)
    }

    return(eoo)
  }

  # ---- Matrix mode
  if (!is.matrix(z)) stop("Matrix mode requires z to be a matrix.")

  if (anyNA(z) && !na.rm) {
    if (verbose) message("Some z values are NA. Returning NA.")
    return(NA_real_)
  }

  keep <- is.finite(z) & (z > presence)

  if (!any(keep)) {
    if (verbose) message("No presence cells found. Returning 0.")
    return(0)
  }

  idx <- which(keep, arr.ind = TRUE)  # row, col
  rownames(idx) <- NULL
  pres_xy <- cbind(x = idx[, 1], y = idx[, 2])

  if (nrow(pres_xy) < 3) {
    if (verbose) message("Fewer than 3 presence cells. Convex hull undefined. Returning 0.")
    return(0)
  }

  xy_chull <- grDevices::chull(pres_xy)
  hull_pts <- data.frame(x = pres_xy[xy_chull, 1], y = pres_xy[xy_chull, 2])
  hull_poly <- sfheaders::sf_polygon(hull_pts, x = "x", y = "y")

  if (!is.null(cell_km)) {
    stopifnot(length(cell_km) == 2, all(is.finite(cell_km)), all(cell_km > 0))
  }

  if (mode == "area") {

    eoo_units <- as.double(sf::st_area(hull_poly))

    if (is.null(cell_km)) {
      eoo <- eoo_units
      eoo_lab <- paste0("EOO = ", round(eoo, 2), " (index^2)")
    } else {
      eoo <- eoo_units * (cell_km[1] * cell_km[2])
      eoo_lab <- paste0("EOO = ", round(eoo, 2), " km2")
    }

  } else { # mode == "cells"

    nr <- nrow(z); nc <- ncol(z)

    bb <- sf::st_bbox(hull_poly)
    cols <- seq(max(1, floor(bb["xmin"])), min(nc, ceiling(bb["xmax"])))
    rows <- seq(max(1, floor(bb["ymin"])), min(nr, ceiling(bb["ymax"])))

    grid_xy <- expand.grid(x = cols, y = rows)
    grid_pts <- sf::st_as_sf(grid_xy, coords = c("x", "y"))

    inside <- sf::st_intersects(grid_pts, hull_poly, sparse = FALSE)[, 1]
    n_cells <- sum(inside)

    if (is.null(cell_km)) {
      eoo <- n_cells
      eoo_lab <- paste0("Cells in hull = ", n_cells)
    } else {
      eoo <- n_cells * (cell_km[1] * cell_km[2])
      eoo_lab <- paste0("Cells in hull = ", n_cells, " | Area = ", round(eoo, 2), " km2")
    }
  }

  if (p) {
    df <- data.frame(x = pres_xy[, 1], y = pres_xy[, 2])

    plt <- ggplot2::ggplot() +
      ggplot2::geom_point(data = df, ggplot2::aes(x = x, y = y)) +
      ggplot2::geom_sf(data = hull_poly, fill = NA, colour = "blue") +
      ggplot2::coord_equal() +
      ggplot2::theme_minimal() +
      ggplot2::ggtitle("Extent of Occurrence (matrix indices)") +
      ggplot2::labs(x = "Column index", y = "Row index", caption = eoo_lab)

    print(plt)
  }

  return(eoo)
}

#' Inertia (range around Centre of Gravity)
#'
#' @description
#' Inertia is the mean square variation around the Centre of Gravity (CoG). It is a
#' measure of range: higher values indicate the population (or biomass) is more spread
#' around its CoG. The computation is density-weighted using `z`.
#'
#' The function supports both point data (vectors of coordinates) and gridded data
#' (a matrix `z`). In matrix mode, each element of `z` is assumed to represent one
#' grid cell. If `x` and `y` are not provided, matrix indices are used
#' (column = x, row = y).
#'
#' @param x Numeric vector or matrix of x-coordinates. In point mode, a numeric vector.
#'   In matrix mode, can be NULL (use indices), a vector of length `ncol(z)`, or a matrix
#'   with the same dimensions as `z`.
#' @param y Numeric vector or matrix of y-coordinates. In point mode, a numeric vector.
#'   In matrix mode, can be NULL (use indices), a vector of length `nrow(z)`, or a matrix
#'   with the same dimensions as `z`.
#' @param z Density values used as weights. Can be a numeric vector (point mode), a numeric
#'   matrix (matrix mode), or a single numeric value (equal weighting). Defaults to 1.
#' @param plot Logical. If TRUE, plot points/cells, the CoG, principal axes, and an ellipse.
#'   Default = FALSE.
#' @param lonlat2km Logical. If TRUE, transform longitude/latitude coordinates (x,y) to km
#'   using \code{SpatialEpi::latlong2grid}. Default = FALSE.
#' @param km2lonlat Logical. If TRUE, transform km coordinates (x,y) to longitude/latitude
#'   using \code{SpatialEpi::grid2latlong}. Default = FALSE.
#' @param rand Logical. If TRUE and `x` and `y` are NULL, generate random example data for
#'   demonstration. Default = FALSE.
#' @param na.rm Logical. If TRUE, remove non-finite values (`NA`, `NaN`, `Inf`) in inputs
#'   before calculation. If FALSE and any non-finite values exist, return `NA`.
#'
#' @return A data frame with:
#' \describe{
#'   \item{cog_x}{x-coordinate of the density-weighted centre of gravity.}
#'   \item{cog_y}{y-coordinate of the density-weighted centre of gravity.}
#'   \item{inert}{Inertia (mean square variation around CoG).}
#'   \item{isotropy}{Isotropy (sqrt(Imin/Imax)) based on principal components of the weighted covariance.}
#' }
#'
#' @export
#'
#' @importFrom stats rnorm median quantile
#' @importFrom SpatialEpi latlong2grid grid2latlong
#' @importFrom graphics par points segments
#'
#' @examples
#' # Point mode (unweighted)
#' x <- c(1, 2, 3, 4, 5)
#' y <- c(2, 1, 3, 5, 4)
#' inertia(x, y)
#'
#' # Point mode (density weighted)
#' z <- c(1, 2, 5, 3, 1)
#' inertia(x, y, z)
#'
#' # Matrix mode (indices used as coordinates)
#' set.seed(1)
#' zmat <- matrix(sample(c(0, 1, 2), 100, replace = TRUE), nrow = 10)
#' inertia(z = zmat)
#'
#' # Matrix mode (provide grid cell centres)
#' xc <- seq(0, 9, length.out = ncol(zmat))
#' yc <- seq(0, 9, length.out = nrow(zmat))
#' inertia(x = xc, y = yc, z = zmat)
#'
#' # NA handling
#' zmat[10:20] <- NA
#' inertia(z = zmat, na.rm = TRUE)
#' inertia(z = zmat, na.rm = FALSE)
#'
#' # Quick demo plot (random data)
#' inertia(rand = TRUE, plot = TRUE)
inertia <- function(x = NULL, y = NULL, z = 1,
                    plot = FALSE,
                    lonlat2km = FALSE, km2lonlat = FALSE,
                    rand = FALSE,
                    na.rm = TRUE) {

  if (plot) {
    if (!requireNamespace("ggplot2", quietly = TRUE)) {
      stop("Package 'ggplot2' is required for plot = TRUE.", call. = FALSE)
    }
    if (!requireNamespace("paletteer", quietly = TRUE)) {
      stop("Package 'paletteer' is required for plot = TRUE.", call. = FALSE)
    }
  }

  # Use rnorm generated data
  if (is.null(x) && is.null(y) && isTRUE(rand)) {
    x <- rnorm(50)
    y <- rnorm(50)
    z <- abs(rnorm(50)^2)
  }

  matrix_mode <- is.matrix(z)

  if (!matrix_mode) {

    if (is.null(x) || is.null(y)) stop("Point mode requires x and y.")
    if (length(z) == 1) z <- rep(z, length(x))
    if (length(x) != length(y) || length(x) != length(z)) {
      stop("In point mode, x, y and z must have the same length (or z length 1).")
    }

    d <- data.frame(x = x, y = y, z = z)

  } else {

    nr <- nrow(z)
    nc <- ncol(z)

    if (is.null(x) && is.null(y)) {

      # FIX: respect na.rm in matrix mode before dropping NA cells
      if (anyNA(z) && !na.rm) return(NA_real_)

      ok <- !is.na(z)  # if na.rm=TRUE we keep non-NA cells; if na.rm=FALSE we already returned above
      xy <- which(ok, arr.ind = TRUE)
      rownames(xy) <- NULL

      d <- data.frame(
        x = xy[, 1],
        y = xy[, 2],
        z = z[ok]
      )

    } else if (is.vector(x) && length(x) == nc && is.vector(y) && length(y) == nr) {

      xy <- expand.grid(x = x, y = y)
      d <- data.frame(x = xy$x, y = xy$y, z = as.vector(t(z)))

    } else if (is.matrix(x) && is.matrix(y) &&
               all(dim(x) == dim(z)) && all(dim(y) == dim(z))) {

      d <- data.frame(x = as.vector(x), y = as.vector(y), z = as.vector(z))

    } else {
      stop(
        "Matrix mode requires either:\n",
        "- supply no x/y (defaults to column/row indices), OR\n",
        "- x = length ncol(z) vector and y = length nrow(z) vector, OR\n",
        "- x and y matrices with same dimensions as z."
      )
    }
  }

  if (na.rm) {
    d <- d[is.finite(d$x) & is.finite(d$y) & is.finite(d$z), , drop = FALSE]
  } else {
    if (any(!is.finite(d$x)) || any(!is.finite(d$y)) || any(!is.finite(d$z))) return(NA)
  }

  if (nrow(d) == 0) return(NA)

  # Measurement transformation (only meaningful when x/y are lon/lat or km)
  if (lonlat2km) {
    xy <- SpatialEpi::latlong2grid(as.matrix(d[, c("x", "y")]))
    d$x <- xy[, 1]
    d$y <- xy[, 2]
  } else if (km2lonlat) {
    xy <- SpatialEpi::grid2latlong(as.matrix(d[, c("x", "y")]))
    d$x <- xy[, 1]
    d$y <- xy[, 2]
  }

  zsum <- sum(d$z)
  if (!is.finite(zsum) || zsum == 0) {
    out <- data.frame(cog_x = NA_real_, cog_y = NA_real_, inert = NA_real_, isotropy = NA_real_)
    return(out)
  }

  cog_x <- sum(d$x * d$z) / zsum
  cog_y <- sum(d$y * d$z) / zsum

  dx <- d$x - cog_x
  dy <- d$y - cog_y

  ix <- sum((dx^2) * d$z) / zsum
  iy <- sum((dy^2) * d$z) / zsum
  inert <- ix + iy

  M11 <- sum(dx^2 * d$z)
  M22 <- sum(dy^2 * d$z)
  M21 <- sum(dx * dy * d$z)
  M12 <- M21
  M <- matrix(c(M11, M12, M21, M22), ncol = 2)

  eg <- eigen(M)
  x1 <- eg$vectors[1, 1]
  y1 <- eg$vectors[2, 1]
  x2 <- eg$vectors[1, 2]
  y2 <- eg$vectors[2, 2]
  r1 <- eg$values[1] / sum(eg$values)

  e1 <- (y1 / x1)^2
  sx1 <- x1 / abs(x1)
  sy1 <- y1 / abs(y1)
  sx2 <- x2 / abs(x2)
  sy2 <- y2 / abs(y2)

  xa <- cog_x + sx1 * sqrt((r1 * inert) / (1 + e1))
  ya <- cog_y + sy1 * sqrt((r1 * inert) / (1 + (1 / e1)))
  xb <- 2 * cog_x - xa
  yb <- 2 * cog_y - ya

  xc <- cog_x + sx2 * sqrt(((1 - r1) * inert) / (1 + (1 / e1)))
  yc <- cog_y + sy2 * sqrt(((1 - r1) * inert) / (1 + e1))
  xd <- 2 * cog_x - xc
  yd <- 2 * cog_y - yc

  Imax <- r1 * inert
  Imin <- (1 - r1) * inert
  isotropy <- sqrt(Imin / Imax)

  if (plot) {

    paletteer::scale_colour_paletteer_c("grDevices::Geyser")
    pal <- paletteer::paletteer_c("grDevices::Geyser", nrow(d))

    d <- d[order(d$z), , drop = FALSE]
    d$pal <- pal

    par(pty = "s")
    plot(d$x, d$y, cex = d$z, col = d$pal, pch = 16)
    segments(xa, ya, xb, yb, col = "blue")
    segments(xc, yc, xd, yd, col = "blue")
    points(cog_x, cog_y, col = "blue", pch = 15)

    car::dataEllipse(c(xa, xb, xc, xd), c(ya, yb, yc, yd),
                     levels = 0.455, add = TRUE, plot.points = FALSE,
                     center.pch = FALSE, col = "lightblue", fill = TRUE)

    points(xa, ya, col = "blue", cex = 1, pch = 16)
    points(xb, yb, col = "blue", cex = 1, pch = 16)
    points(xc, yc, col = "blue", cex = 1, pch = 16)
    points(xd, yd, col = "blue", cex = 1, pch = 16)

    text(x = median(d$x), y = max(d$y), labels = paste0("CoG: ", round(cog_x, 2), ", ", round(cog_y, 2)))
    text(x = median(d$x), y = max(d$y) * 0.9, labels = paste0("Inertia: ", round(inert, 2)))
    text(x = median(d$x), y = max(d$y) * 0.8, labels = paste0("Isotropy: ", round(isotropy, 2)))
  }

  output <- data.frame(cog_x = cog_x, cog_y = cog_y, inert = inert, isotropy = isotropy)
  return(output)
}

